package my.gym;

public class setting {

    private String id_app;
    private String facebook_app;
    private String twitter_app;
    private String instagram_app;
    private String about_app;
    private String terms_app;
    private String logo_app;

    public String getId_app() {
        return id_app;
    }

    public void setId_app(String id_app) {
        this.id_app = id_app;
    }

    public String getFacebook_app() {
        return facebook_app;
    }

    public void setFacebook_app(String facebook_app) {
        this.facebook_app = facebook_app;
    }

    public String getTwitter_app() {
        return twitter_app;
    }

    public void setTwitter_app(String twitter_app) {
        this.twitter_app = twitter_app;
    }

    public String getInstagram_app() {
        return instagram_app;
    }

    public void setInstagram_app(String instagram_app) {
        this.instagram_app = instagram_app;
    }

    public String getAbout_app() {
        return about_app;
    }

    public void setAbout_app(String about_app) {
        this.about_app = about_app;
    }

    public String getTerms_app() {
        return terms_app;
    }

    public void setTerms_app(String terms_app) {
        this.terms_app = terms_app;
    }

    public String getLogo_app() {
        return logo_app;
    }

    public void setLogo_app(String logo_app) {
        this.logo_app = logo_app;
    }
}
