package my.gym;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import my.gym.R;

import java.util.ArrayList;
import java.util.List;

public class ProductDetailsActivity extends AppCompatActivity {
    public static final String EXTRA_product_id = "product_id";
    public static final String EXTRA_product_title = "product_title";
    public static final String EXTRA_product_description= "product_description";
    public static final String EXTRA_product_price = "product_price";
    public static final String EXTRA_product_shipping = "product_shipping";
    public static final String EXTRA_product_link = "product_link";
    public static final String EXTRA_product_stock = "product_stock";
    public static final String EXTRA_product_save = "product_save";
    public static final String EXTRA_product_image = "product_image";
    public static final String EXTRA_product_category = "product_category";
    public static final String EXTRA_categories_products_id = "categories_products_id";
    public static final String EXTRA_categories_products_title = "categories_products_title";
    public static final String EXTRA_categories_products_image = "categories_products_image";
    private static final String image_url = "http://fitnessgymapp.000webhostapp.com/ionic/ionic/backend/images/";
    private RequestQueue mRequestQueue;
    private RecyclerView mRecyclerView;
    private TextView productTiltle;
    private ImageView productImage;
    private TextView productPrice;
    private TextView productSave;
    private TextView productShipping;
    private TextView productStock;
    private TextView productDescription;
    private TextView productCat;

    private Button buyProduct;
    private List <product> ProductsRelatedList;

    private View mRecyclerrView;
    private View mProgressView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details);
        mRecyclerrView = findViewById(R.id.productDets);
        mProgressView = findViewById(R.id.login_progress);
        mRecyclerView = findViewById(R.id.relatedProducts);
        mRequestQueue = Volley.newRequestQueue(getApplicationContext());
        productTiltle = findViewById(R.id.productTitle);
        productImage = findViewById(R.id.productImage);
        productPrice = findViewById(R.id.priceValue);
        productShipping = findViewById(R.id.shippingValue2);
        productSave = findViewById(R.id.saveValue);
        productStock = findViewById(R.id.stock);
        productCat = findViewById(R.id.productCat);
        productDescription = findViewById(R.id.productDesc);
        buyProduct = findViewById(R.id.Buy);
        ProductsRelatedList = new ArrayList();
        productTiltle.setText(getIntent().getStringExtra(EXTRA_product_title));
        productPrice.setText(getIntent().getStringExtra(EXTRA_product_price));
       productShipping.setText(getIntent().getStringExtra(EXTRA_product_shipping));
        productSave.setText(getIntent().getStringExtra(EXTRA_product_save));
        productStock.setText(getIntent().getStringExtra(EXTRA_product_stock));
        String product_description = getIntent().getStringExtra(EXTRA_product_description)
                .replace("&amp;uuml;","u");

        for (int i =0;i<StoreActivity.productList.size();i++)
        {
            if(StoreActivity.productList.get(i).getProduct_category().equals(getIntent()
                    .getStringExtra(EXTRA_product_category)))
            {
                ProductsRelatedList.add(StoreActivity.productList.get(i));
            }
        }

        product_description = product_description.replace("&amp;ouml;","o");
        product_description = product_description.replace("&amp;auml;","a");
        product_description = product_description.replace("&amp;nbsp;"," ");
        product_description = product_description.replace("&amp;ndash;","-");
        product_description = product_description.replace("&amp;bull;",".");
        product_description = product_description.replace("&amp;amp;","&");
        product_description = product_description.replace("&amp;trade;"," ");
        product_description = product_description.replace("&amp;"," ");
        productDescription.setText(product_description);
        productCat.setText(getIntent().getStringExtra(EXTRA_categories_products_title));

        buyProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(getIntent().getStringExtra(EXTRA_product_link)));
                startActivity(browserIntent);
            }
        });
        String product_image_url = image_url + getIntent().getStringExtra(EXTRA_product_image);
        /* *************************Request an image****************************** */

        ImageRequest imageRequest = new ImageRequest(product_image_url, new Response.Listener<Bitmap>() {
            @Override
            public void onResponse(Bitmap response) {
                productImage.setImageBitmap(response);
            }
        }, 0, 0, ImageView.ScaleType.CENTER_CROP, null, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),"something went Wrong",
                        Toast.LENGTH_LONG).show();
                error.printStackTrace();
            }
        });

        mRequestQueue.add(imageRequest);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(ProductDetailsActivity.this));
        ProductDetailsActivity.ActivityAdapter adabter = new ProductDetailsActivity.ActivityAdapter(ProductsRelatedList);
        mRecyclerView.setAdapter(adabter);
        /* *************************Request an image****************************** */
      //List<product> x =  getProductCategories();

    }



    public static Intent newIntent(Context packageName, product product) {
        Intent intent = new Intent(packageName, ProductDetailsActivity.class);
        intent.putExtra(EXTRA_product_id, product.getProductId());
        intent.putExtra(EXTRA_product_title, product.getProduct_title());
        intent.putExtra(EXTRA_product_description, product.getProduct_description());
        intent.putExtra(EXTRA_product_price, product.getProduct_price());
        intent.putExtra(EXTRA_product_shipping, product.getProduct_shipping());
        intent.putExtra(EXTRA_product_link, product.getProduct_link());
        intent.putExtra(EXTRA_product_stock, product.getProduct_stock());
        intent.putExtra(EXTRA_product_save, product.getProduct_save());
        intent.putExtra(EXTRA_product_image, product.getProduct_image());
        intent.putExtra(EXTRA_product_category, product.getProduct_category());
        intent.putExtra(EXTRA_categories_products_id, product.getCategories_products_id());
        intent.putExtra(EXTRA_categories_products_image, product.getCategories_products_image());
        intent.putExtra(EXTRA_categories_products_title, product.getCategories_products_title());
        return intent;

    }


    public class ActivityHolder extends RecyclerView.ViewHolder {
        private ImageView image;
        private TextView price;
        private TextView shipping;
        private TextView save;
        private TextView title;
        private Button mButton;


        public ActivityHolder(View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.productPhoto);
            price = itemView.findViewById(R.id.productPrice);
            shipping = itemView.findViewById(R.id.productShipping);
            save = itemView.findViewById(R.id.productSave);
            title = itemView.findViewById(R.id.productTitle);
            mButton = itemView.findViewById(R.id.viewProduct);
        }

        public void bindProduct(product mProduct) {




            title.setText(mProduct.getProduct_title());
            price.setText(mProduct.getProduct_price());
            save.setText(mProduct.getProduct_save());
            shipping.setText(mProduct.getProduct_shipping());

            String product_image_url = image_url + mProduct.getProduct_image();

            /* *************************Request an image****************************** */

            ImageRequest imageRequest = new ImageRequest(product_image_url, new Response.Listener<Bitmap>() {
                @Override
                public void onResponse(Bitmap response) {
                    image.setImageBitmap(response);
                }
            }, 0, 0, ImageView.ScaleType.FIT_XY, null, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(),"something went Wrong",
                            Toast.LENGTH_LONG).show();
                    error.printStackTrace();
                }
            });

            mRequestQueue.add(imageRequest);

            /* *************************Request an image****************************** */

        }


    }



    public class ActivityAdapter extends RecyclerView.Adapter<ProductDetailsActivity.ActivityHolder> {

        private List<product> products;
        public ActivityAdapter(List<product> mproducts) {
            products = mproducts;
        }

        @Override
        public ProductDetailsActivity.ActivityHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(ProductDetailsActivity.this);
            View v = inflater.inflate(R.layout.product, parent, false);

            return new ProductDetailsActivity.ActivityHolder(v);
        }

        @Override
        public void onBindViewHolder(ProductDetailsActivity.ActivityHolder holder, int position) {
            final product product = products.get(position);
            holder.bindProduct(product);
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = ProductDetailsActivity.newIntent(getApplicationContext(),product);
                    startActivity(i);
                }
            });
        }

        @Override
        public int getItemCount() {
            return products.size();
        }
    }



}
