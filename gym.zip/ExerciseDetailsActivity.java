package my.gym;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import my.gym.R;

public class ExerciseDetailsActivity extends AppCompatActivity {
    public static final String EXTRA_exercise_id = "exercise_id";
    public static final String EXTRA_exercise_equipment = "exercise_equipment";
    public static final String EXTRA_exercise_title = "exercise_title";
    public static final String EXTRA_exercise_reps = "exercise_reps";
    public static final String EXTRA_exercise_dificult = "exercise_dificult";
    public static final String EXTRA_exercise_sets = "exercise_sets";
    public static final String EXTRA_exercise_steps = "exercise_steps";
    public static final String EXTRA_exercise_time = "exercise_time";
    public static final String EXTRA_exercise_image = "exercise_image";

    private static final String image_url = "http://fitnessgymapp.000webhostapp.com/ionic/ionic/backend/images/";
    private RequestQueue mRequestQueue;
    private ImageView exerImage;
    private TextView repstext;
    private TextView setstext;
    private TextView difficultyText ;
    private TextView restText;
    private TextView exerTitle;
    private TextView steps;
    private TextView trainerfit;
    private TextView exercisesFooter;
    private TextView workoutsFooter;
    private TextView storeFooter;
    private android.support.v7.widget.Toolbar toolbar;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_details);
        mRequestQueue = Volley.newRequestQueue(getApplicationContext());
        exerImage = findViewById(R.id.exerciseimg);
        repstext = findViewById(R.id.repsValue);
        setstext = findViewById(R.id.setsValue);
        difficultyText = findViewById(R.id.difficultyValue);
        exerTitle = findViewById(R.id.exertitl);
        steps = findViewById(R.id.stps);
        restText = findViewById(R.id.restValue);
        repstext.setText(getIntent().getStringExtra(EXTRA_exercise_reps));
        setstext.setText(getIntent().getStringExtra(EXTRA_exercise_sets));
        difficultyText.setText(getIntent().getStringExtra(EXTRA_exercise_dificult));
        steps.setText(getIntent().getStringExtra(EXTRA_exercise_steps));
        restText.setText("90 sec");
        exerTitle.setText(getIntent().getStringExtra(EXTRA_exercise_title));
        String exercise_image_url = image_url + getIntent().getStringExtra(EXTRA_exercise_image);
        /* *************************Request an image****************************** */
        trainerfit = findViewById(R.id.trainerfit);
        exercisesFooter = findViewById(R.id.exercises);
        workoutsFooter = findViewById(R.id.workoutsFooter);
        storeFooter = findViewById(R.id.store);
        trainerfit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ExerciseDetailsActivity.this,mainPage.class);
                startActivity(i);

            }
        });
        exercisesFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ExerciseDetailsActivity.this,ExercisesActivity.class);
                startActivity(i);

            }
        });
        workoutsFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ExerciseDetailsActivity.this,workoutsActivity.class);
                startActivity(i);

            }
        });
        storeFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ExerciseDetailsActivity.this,StoreActivity.class);
                startActivity(i);

            }
        });


        ImageRequest imageRequest = new ImageRequest(exercise_image_url, new Response.Listener<Bitmap>() {
            @Override
            public void onResponse(Bitmap response) {
                exerImage.setImageBitmap(response);
            }
        }, 0, 0, ImageView.ScaleType.CENTER_CROP, null, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),"something went Wrong",
                        Toast.LENGTH_LONG).show();
                error.printStackTrace();
            }
        });

        mRequestQueue.add(imageRequest);

        /* *************************Request an image****************************** */

     /*   Toast.makeText(getApplicationContext(),getIntent().getStringExtra(EXTRA_exercise_dificult)
                ,Toast.LENGTH_LONG).show();*/
        toolbar = findViewById(R.id.toolbar);
        Drawable drawable = ContextCompat.getDrawable(getApplicationContext(), R.drawable.ic_menu_tomainpage);
        toolbar.setNavigationIcon(drawable);

        setSupportActionBar(toolbar);
        toolbar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ExerciseDetailsActivity.this,mainPage.class);
                startActivity(i);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);


        return true;
    }

    /**   select the id of the selected menu item
     *  choose  the desired item to select
     * @param item the selected item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.aboutUs) {

       Intent i = new Intent(ExerciseDetailsActivity.this,SettingActivity.class);
       startActivity(i);

        }

        return super.onOptionsItemSelected(item);
    }



    public static Intent newIntent(Context packageName, exercisesJson exercise) {
        Intent intent = new Intent(packageName, ExerciseDetailsActivity.class);
        intent.putExtra(EXTRA_exercise_id, exercise.getExercise_id());
        intent.putExtra(EXTRA_exercise_equipment, exercise.getExercise_equipment());
        intent.putExtra(EXTRA_exercise_title, exercise.getExercise_title());
        intent.putExtra(EXTRA_exercise_reps, exercise.getExercise_reps());
        intent.putExtra(EXTRA_exercise_dificult, exercise.getExercise_dificult());
        intent.putExtra(EXTRA_exercise_sets, exercise.getExercise_sets());
        intent.putExtra(EXTRA_exercise_steps, exercise.getExercise_steps());
        intent.putExtra(EXTRA_exercise_time, exercise.getExercise_time());
        intent.putExtra(EXTRA_exercise_image, exercise.getExercise_image());
        return intent;

    }

}
