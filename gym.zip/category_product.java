package my.gym;

public class category_product {

    private String categories_products_id;
    private String categories_products_title;
    private String categories_products_image;

    public String getCategories_products_id() {
        return categories_products_id;
    }

    public void setCategories_products_id(String categories_products_id) {
        this.categories_products_id = categories_products_id;
    }

    public String getCategories_products_title() {
        return categories_products_title;
    }

    public void setCategories_products_title(String categories_products_title) {
        this.categories_products_title = categories_products_title;
    }

    public String getCategories_products_image() {
        return categories_products_image;
    }

    public void setCategories_products_image(String categories_products_image) {
        this.categories_products_image = categories_products_image;
    }
}
