package my.gym;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import my.gym.R;

public class DietDetailsActivity extends AppCompatActivity {
    public static final String EXTRA_diet_ID = "diet_id";
    public static final String EXTRA_diet_type = "diet_type";
    public static final String EXTRA_diet_title= "diet_title";
    public static final String EXTRA_diet_description = "diet_description";
    public static final String EXTRA_diet_list = "diet_list";
    public static final String EXTRA_diet_image = "diet_image";
    public static final String EXTRA_diet_colories = "diet_calories";
    public static final String EXTRA_diet_carbs = "diet_carbs";
    public static final String EXTRA_diet_protein = "diet_protein";
    public static final String EXTRA_diet_fat = "diet_fat";

    private ImageView dietImage;
    private TextView imageAddress;
    private TextView imageTiltle;
    private TextView dietDescription;
    private TextView dietList;
    private TextView caloriesCycle;
    private TextView carbsCycle;
    private TextView proteinCycle;
    private TextView fatCycle;
    private Button calculatorButton;
    private static final String image_url = "http://fitnessgymapp.000webhostapp.com/ionic/ionic/backend/images/";
    private RequestQueue mRequestQueue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diet_details);
        mRequestQueue = Volley.newRequestQueue(getApplicationContext());
        dietImage = findViewById(R.id.dietPhoto);
        imageAddress = findViewById(R.id.imageAddress);
        imageTiltle = findViewById(R.id.imageTiltle);
        dietDescription = findViewById(R.id.dietDescription);
        dietList = findViewById(R.id.dietList);
        caloriesCycle = findViewById(R.id.caloriescycll);
        carbsCycle = findViewById(R.id.carbsCycle);
        proteinCycle = findViewById(R.id.proteincycle);
        fatCycle = findViewById(R.id.fatcycle);
        calculatorButton = findViewById(R.id.calculatorButtton);
        imageAddress.setText(getIntent().getStringExtra(EXTRA_diet_title));
        imageTiltle.setText(getIntent().getStringExtra(EXTRA_diet_type));
        String description =  getIntent().getStringExtra(EXTRA_diet_description)
                .replace("&amp;", " ");
        description = description.replace("#39;","i");
        description = description.replace("mdash;","-");
        description = description.replace("&amp;nbsp;"," ");
        dietDescription.setText(description);
        String dietListt =  getIntent().getStringExtra(EXTRA_diet_list)
                .replace("&amp;", " ");
        dietListt = dietListt.replace("nbsp;"," ");
        dietListt = dietListt.replace("mdash;","-");
        dietList.setText(dietListt);
        caloriesCycle.setText(getIntent().getStringExtra(EXTRA_diet_colories));
        carbsCycle.setText(getIntent().getStringExtra(EXTRA_diet_carbs));
        proteinCycle.setText(getIntent().getStringExtra(EXTRA_diet_protein));
        fatCycle.setText(getIntent().getStringExtra(EXTRA_diet_fat));
        calculatorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(DietDetailsActivity.this,CalculatorActivity.class);
                startActivity(i);
            }
        });
        String diet_image_url = image_url + getIntent().getStringExtra(EXTRA_diet_image);
        /* *************************Request an image****************************** */

        ImageRequest imageRequest = new ImageRequest(diet_image_url, new Response.Listener<Bitmap>() {
            @Override
            public void onResponse(Bitmap response) {
                dietImage.setImageBitmap(response);
            }
        }, 0, 0, ImageView.ScaleType.CENTER_CROP, null, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),"something went Wrong",
                        Toast.LENGTH_LONG).show();
                error.printStackTrace();
            }
        });

        mRequestQueue.add(imageRequest);

        /* *************************Request an image****************************** */
    }



    public static Intent newIntent(Context packageName, DietPlan diet) {
        Intent intent = new Intent(packageName, DietDetailsActivity.class);
        intent.putExtra(EXTRA_diet_ID, diet.getId());
        intent.putExtra(EXTRA_diet_type, diet.getDiet_type());
        intent.putExtra(EXTRA_diet_title, diet.getDiet_title());
        intent.putExtra(EXTRA_diet_description, diet.getDiet_description());
        intent.putExtra(EXTRA_diet_list, diet.getDiet_list());
        intent.putExtra(EXTRA_diet_image, diet.getDiet_image());
        intent.putExtra(EXTRA_diet_colories, diet.getDiet_calories());
        intent.putExtra(EXTRA_diet_carbs, diet.getDiet_carbs());
        intent.putExtra(EXTRA_diet_protein, diet.getDiet_protein());
        intent.putExtra(EXTRA_diet_fat, diet.getDiet_fat());
        return intent;

    }
}
