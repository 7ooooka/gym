package my.gym;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import my.gym.R;

import java.util.ArrayList;
import java.util.List;

import retrofit.Call;
import retrofit.Callback;
import retrofit.GsonConverterFactory;
import retrofit.Retrofit;

public class categoryProductsActivity extends AppCompatActivity {
    public static final String EXTRA_categories_products_id = "categories_products_id";
    public static final String EXTRA_categories_products_title = "categories_products_title";
    public static final String EXTRA_categories_products_image = "categories_products_image";
    private static final String image_url = "http://fitnessgymapp.000webhostapp.com/ionic/ionic/backend/images/";
    private List<product> relatedProductsList;
    private RequestQueue mRequestQueue;
    private RecyclerView mRecyclerView;
    private View mRecyclerrView;
    private View mProgressView;
    private   String categoriesid;
    public static List<product> productList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_products);

        mRecyclerrView = findViewById(R.id.categsssss);
        mProgressView = findViewById(R.id.login_progress);
        productList = new ArrayList<>();
        mRecyclerView = findViewById(R.id.categoriessss);
        mRequestQueue = Volley.newRequestQueue(getApplicationContext());
        relatedProductsList = new ArrayList<>();
         categoriesid = getIntent().getStringExtra(EXTRA_categories_products_title);
        Retrofit retrofit = new Retrofit.Builder().baseUrl(API.workoutURL)
                .addConverterFactory(GsonConverterFactory.create()).build();
        API api = retrofit.create(API.class);
        Call<List<product>> call = api.getProducts();
        showProgress(true);
        call.enqueue(new Callback<List<product>>() {
            @Override
            public void onResponse(retrofit.Response<List<product>> response, Retrofit retrofit) {
                try {
                    if(response.body()!=null)
                    {
                        List<product> products = response.body();

                        for (int i = 0; i < products.size(); i++) {
                            product product = new product();
                            product.setProductId(products.get(i).getProductId());
                            product.setProduct_title(products.get(i).getProduct_title());
                            product.setProduct_description(products.get(i).getProduct_description());
                            product.setProduct_price(products.get(i).getProduct_price());
                            product.setProduct_link(products.get(i).getProduct_link());
                            product.setProduct_stock(products.get(i).getProduct_stock());
                            product.setProduct_shipping(products.get(i).getProduct_shipping());
                            product.setProduct_save(products.get(i).getProduct_save());
                            product.setProduct_image(products.get(i).getProduct_image());
                            product.setProduct_category(products.get(i).getProduct_category());
                            product.setCategories_products_id(products.get(i).getCategories_products_id());
                            product.setCategories_products_title(products.get(i).getCategories_products_title());
                            product.setCategories_products_image(products.get(i).getCategories_products_image());
                            productList.add(product);
                        }
                        for (int j=0 ;j< productList.size();j++)
                        {
                           // Toast.makeText(getApplicationContext(),String.valueOf(productList.get(j).getProduct_title()), Toast.LENGTH_SHORT).show();

                        /*    if (productList.get(j).getProduct_title().equals(categoriesid))
                            {
                                relatedProductsList.add(productList.get(j));
                            }*/
                        }
                      /*    Toast.makeText(getApplicationContext(),String.valueOf(relatedProductsList.size())
                         ,Toast.LENGTH_LONG).show();*/
                        mRecyclerView.setLayoutManager(new LinearLayoutManager(categoryProductsActivity.this));
                        categoryProductsActivity.ActivityAdapter adabter = new categoryProductsActivity.ActivityAdapter(productList);
                        mRecyclerView.setAdapter(adabter);
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "products does not exist", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "error", Toast.LENGTH_SHORT).show();
                    Log.d("onResponse", "There is an error");
                    e.printStackTrace();
                }
                showProgress(false);
            }
            @Override
            public void onFailure(Throwable t) {
                t.printStackTrace();
                showProgress(false);
            }
        });

    }

    public static Intent newIntent(Context packageName, category_product category) {
        Intent intent = new Intent(packageName, categoryProductsActivity.class);
        intent.putExtra(EXTRA_categories_products_id, category.getCategories_products_id());
        intent.putExtra(EXTRA_categories_products_title, category.getCategories_products_title());
        intent.putExtra(EXTRA_categories_products_image, category.getCategories_products_image());
        return intent;

    }


    public class ActivityHolder extends RecyclerView.ViewHolder {
        private ImageView image;
        private TextView price;
        private TextView shipping;
        private TextView save;
        private TextView title;
        private Button mButton;


        public ActivityHolder(View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.productPhoto);
            price = itemView.findViewById(R.id.productPrice);
            shipping = itemView.findViewById(R.id.productShipping);
            save = itemView.findViewById(R.id.productSave);
            title = itemView.findViewById(R.id.productTitle);
            mButton = itemView.findViewById(R.id.viewProduct);
        }

        public void bindProduct(product mProduct) {




            title.setText(mProduct.getProduct_title());
            price.setText(mProduct.getProduct_price());
            save.setText(mProduct.getProduct_save());
            shipping.setText(mProduct.getProduct_shipping());

            String product_image_url = image_url + mProduct.getProduct_image();

            /* *************************Request an image****************************** */

            ImageRequest imageRequest = new ImageRequest(product_image_url, new Response.Listener<Bitmap>() {
                @Override
                public void onResponse(Bitmap response) {
                    image.setImageBitmap(response);
                }
            }, 0, 0, ImageView.ScaleType.FIT_XY, null, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(),"something went Wrong",
                            Toast.LENGTH_LONG).show();
                    error.printStackTrace();
                }
            });

            mRequestQueue.add(imageRequest);

            /* *************************Request an image****************************** */

        }


    }



    public class ActivityAdapter extends RecyclerView.Adapter<categoryProductsActivity.ActivityHolder> {

        private List<product> products;
        public ActivityAdapter(List<product> mproducts) {
            products = mproducts;
        }

        @Override
        public categoryProductsActivity.ActivityHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(categoryProductsActivity.this);
            View v = inflater.inflate(R.layout.product, parent, false);

            return new categoryProductsActivity.ActivityHolder(v);
        }

        @Override
        public void onBindViewHolder(categoryProductsActivity.ActivityHolder holder, int position) {
            final product product = products.get(position);
            holder.bindProduct(product);
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = ProductDetailsActivity.newIntent(getApplicationContext(),product);
                    startActivity(i);
                }
            });
        }

        @Override
        public int getItemCount() {
            return products.size();
        }
    }


    /************************************************************/
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mRecyclerrView.setVisibility(show ? View.GONE : View.VISIBLE);
            mRecyclerrView.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mRecyclerrView.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mRecyclerrView.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }

    /*************************************************************/

}
