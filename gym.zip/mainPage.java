package my.gym;


import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import my.gym.R;


/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 */
public class mainPage extends AppCompatActivity {

private RelativeLayout mRelativeLayout;
    private RelativeLayout store;
    private RelativeLayout DietPlansRelativeLayout;
    private RelativeLayout exers;
    private RelativeLayout calculate;
    private RelativeLayout register;
    private TextView trainerfit;
    private TextView exercisesFooter;
    private TextView workoutsFooter;
    private TextView storeFooter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);
        mRelativeLayout = findViewById(R.id.work);
        register = findViewById(R.id.register);
        DietPlansRelativeLayout = findViewById(R.id.dietPlans);
        exers = findViewById(R.id.exers);
        calculate = findViewById(R.id.calculate);
        store = findViewById(R.id.RelativeStore);

        trainerfit = findViewById(R.id.trainerfit);
        exercisesFooter = findViewById(R.id.exercises);
        workoutsFooter = findViewById(R.id.workoutsFooter);
        storeFooter = findViewById(R.id.store);
        trainerfit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(mainPage.this,mainPage.class);
                startActivity(i);

            }
        });
        exercisesFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(mainPage.this,ExercisesActivity.class);
                startActivity(i);

            }
        });
        workoutsFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(mainPage.this,workoutsActivity.class);
                startActivity(i);

            }
        });
        storeFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(mainPage.this,StoreActivity.class);
                startActivity(i);

            }
        });



   mRelativeLayout.setOnClickListener(new View.OnClickListener() {
       @Override
       public void onClick(View view) {

           Intent i = new Intent(mainPage.this,workoutsActivity.class);
           startActivity(i);

       }
   });
        DietPlansRelativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(mainPage.this,DietPlansActivity.class);
                startActivity(i);
            }
        });

        store.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(mainPage.this,StoreActivity.class);
                startActivity(i);
            }
        });

        exers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(mainPage.this,ExercisesActivity.class);
                startActivity(i);
            }
        });

        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(mainPage.this,CalculatorActivity.class);
                startActivity(i);
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(mainPage.this,RegisterActivity.class);
                startActivity(i);
            }
        });
        if(!isNetworkConnectionAvailable())
        {

            try {
                AlertDialog alertDialog = new AlertDialog.Builder(mainPage.this).create();

                alertDialog.setTitle("Network");
                alertDialog.setMessage("Internet not available, Cross check your internet connectivity and try again");
                alertDialog.setIcon(android.R.drawable.ic_dialog_alert);
              alertDialog.setButton(Dialog.BUTTON_POSITIVE, "OK",
                      new DialogInterface.OnClickListener() {
                  @Override
                  public void onClick(DialogInterface dialogInterface, int i) {
                     finish();
                  }
              });



                alertDialog.show();
                alertDialog.setCanceledOnTouchOutside(false);
                alertDialog.setCancelable(false);

            }
            catch(Exception e)
            {
                Toast.makeText(mainPage.this,
                        "Exception",Toast.LENGTH_LONG).show();
            }
        }

    }

    // added as an instance method to an Activity
    boolean isNetworkConnectionAvailable() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = cm.getActiveNetworkInfo();
        if (info == null) return false;
        NetworkInfo.State network = info.getState();
        return (network == NetworkInfo.State.CONNECTED || network == NetworkInfo.State.CONNECTING);
    }

}