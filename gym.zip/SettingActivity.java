package my.gym;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import my.gym.R;

import java.util.ArrayList;
import java.util.List;

import retrofit.Call;
import retrofit.Callback;
import retrofit.GsonConverterFactory;
import retrofit.Retrofit;

public class SettingActivity extends AppCompatActivity {
private ImageView logo;
private TextView facebook;
    private TextView twitter;
    private TextView instagram;
    private Button shareApp;
    private TextView about;
    private List<setting> settingsList;
    private View mRecyclerrView;
    private View mProgressView;
    private RequestQueue mRequestQueue;
    private static final String image_url = "http://fitnessgymapp.000webhostapp.com/ionic/ionic/backend//images/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        mRequestQueue = Volley.newRequestQueue(getApplicationContext());
        mRecyclerrView = findViewById(R.id.settingss);
        mProgressView = findViewById(R.id.login_progress);
        logo = findViewById(R.id.logo);
        facebook = findViewById(R.id.facebook);
        twitter = findViewById(R.id.twitter);
        instagram = findViewById(R.id.instagram);
        shareApp = findViewById(R.id.shareApp);
        about = findViewById(R.id.about);
        settingsList = new ArrayList<>();
        shareApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT,"Hi I found a Personal Trainer App, It's Free");
                i.putExtra(Intent.EXTRA_SUBJECT,"Trainer Fit");
                i = Intent.createChooser(i,"Please choose");
                startActivity(i);
            }
        });


        Retrofit retrofit = new Retrofit.Builder().baseUrl(API.workoutURL)
                .addConverterFactory(GsonConverterFactory.create()).build();
        API api = retrofit.create(API.class);
        Call<List<setting>> call = api.getSettings();
        showProgress(true);
        call.enqueue(new Callback<List<setting>>() {
            @Override
            public void onResponse(retrofit.Response<List<setting>> response, Retrofit retrofit) {
                try {
                    if(response.body()!=null)
                    {
                        List<setting> settings = response.body();

                        for (int i = 0; i < settings.size(); i++) {
                            setting setting = new setting();
                            setting.setId_app(settings.get(i).getId_app());
                            setting.setFacebook_app(settings.get(i).getFacebook_app());
                            setting.setTwitter_app(settings.get(i).getTwitter_app());
                            setting.setInstagram_app(settings.get(i).getInstagram_app());
                            setting.setAbout_app(settings.get(i).getAbout_app());
                            setting.setTerms_app(settings.get(i).getTerms_app());
                            setting.setLogo_app(settings.get(i).getLogo_app());
                            settingsList.add(setting);
                        }


                        about.setText(settingsList.get(0).getAbout_app());

                        facebook.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Intent browserIntent = new Intent(Intent.ACTION_VIEW,
                                        Uri.parse(settingsList.get(0).getFacebook_app()));
                                startActivity(browserIntent);
                            }
                        });
                        twitter.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Intent browserIntent = new Intent(Intent.ACTION_VIEW,
                                        Uri.parse(settingsList.get(0).getTwitter_app()));
                                startActivity(browserIntent);
                            }
                        });
                        instagram.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Intent browserIntent = new Intent(Intent.ACTION_VIEW,
                                        Uri.parse(settingsList.get(0).getInstagram_app()));
                                startActivity(browserIntent);
                            }
                        });



                        String setting_image_url = image_url + settingsList.get(0).getLogo_app();

                        /* *************************Request an image****************************** */

                        ImageRequest imageRequest = new ImageRequest(setting_image_url, new Response.Listener<Bitmap>() {
                            @Override
                            public void onResponse(Bitmap response) {
                                logo.setImageBitmap(response);
                            }
                        }, 0, 0, ImageView.ScaleType.FIT_XY, null, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Toast.makeText(getApplicationContext(),"something went Wrong",
                                        Toast.LENGTH_LONG).show();
                                error.printStackTrace();
                            }
                        });

                        mRequestQueue.add(imageRequest);

                        /* *************************Request an image****************************** */


                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "settings does not exist", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Log.d("onResponse", "There is an error");
                    e.printStackTrace();
                }
                showProgress(false);
            }
            @Override
            public void onFailure(Throwable t) {
                t.printStackTrace();
                showProgress(false);
            }
        });

    }


    /************************************************************/
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mRecyclerrView.setVisibility(show ? View.GONE : View.VISIBLE);
            mRecyclerrView.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mRecyclerrView.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mRecyclerrView.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }

    /*************************************************************/
}
