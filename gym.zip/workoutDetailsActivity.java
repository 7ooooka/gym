package my.gym;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import my.gym.R;

import java.util.ArrayList;
import java.util.List;

import retrofit.Call;
import retrofit.Callback;
import retrofit.GsonConverterFactory;
import retrofit.Retrofit;

public class workoutDetailsActivity extends AppCompatActivity {
    public static final String EXTRA_workout_ID = "workout_ID";
    public static final String EXTRA_workout_title = "workout_title";
    public static final String EXTRA_workout_Duration = "workout_Duration";
    public static final String EXTRA_workout_difficulty = "workout_difficulty";
    public static final String EXTRA_workout_goals = "workout_goals";
    public static final String EXTRA_workout_description = "workout_description";
    public static final String EXTRA_workout_cover = "workout_cover";
    private static final String image_url = "http://fitnessgymapp.000webhostapp.com/ionic/ionic/backend/images/";
    private RequestQueue mRequestQueue;
    private ImageView wdetailImage;
    private View mRecyclerrView;
    private View mProgressView;
    private RecyclerView mRecyclerView;
    private List<exercisesJson> workouts_exercisesList;
private TextView Workoutdesc;
private TextView details_diffculty;
    private TextView wtiltle;
    private TextView wDuration;
    private TextView details_goal;
    private TextView trainerfit;
    private TextView exercisesFooter;
    private TextView workoutsFooter;
    private TextView storeFooter;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout_details);
        mRecyclerrView = findViewById(R.id.workoutdetails);
        mProgressView = findViewById(R.id.login_progress);
        mRecyclerView = findViewById(R.id.workoutexercisess);
        Workoutdesc = findViewById(R.id.describtion);
        wdetailImage = findViewById(R.id.wdetailImage);
        workouts_exercisesList = new ArrayList<>();
        details_diffculty = findViewById(R.id.details_diffculty);
        wtiltle = findViewById(R.id.wTiltle);
        wDuration = findViewById(R.id.wDuration);
        details_goal = findViewById(R.id.details_goal);
        mRequestQueue = Volley.newRequestQueue(getApplicationContext());

        trainerfit = findViewById(R.id.trainerfit);
        exercisesFooter = findViewById(R.id.exercises);
        workoutsFooter = findViewById(R.id.workoutsFooter);
        storeFooter = findViewById(R.id.store);
        trainerfit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(workoutDetailsActivity.this,mainPage.class);
                startActivity(i);

            }
        });
        exercisesFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(workoutDetailsActivity.this,ExercisesActivity.class);
                startActivity(i);

            }
        });
        workoutsFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(workoutDetailsActivity.this,workoutsActivity.class);
                startActivity(i);

            }
        });
        storeFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(workoutDetailsActivity.this,StoreActivity.class);
                startActivity(i);

            }
        });



         String workoutId = getIntent().getStringExtra(EXTRA_workout_ID);
        String workoutDesc = getIntent().getStringExtra(EXTRA_workout_description);
        String workoutGoals = getIntent().getStringExtra(EXTRA_workout_goals);
        String workoutDifficult = getIntent().getStringExtra(EXTRA_workout_difficulty);
        String workoutImage = getIntent().getStringExtra(EXTRA_workout_cover);
        String workoutTiltle = getIntent().getStringExtra(EXTRA_workout_title);
        String workoutDuration = getIntent().getStringExtra(EXTRA_workout_Duration);
        Workoutdesc.setText(workoutDesc);
        showProgress(true);
         //Toast.makeText(getApplicationContext(),  workoutId , Toast.LENGTH_SHORT).show();
        details_diffculty.setText(workoutDifficult);
        details_diffculty.setText(workoutGoals);
        wtiltle.setText(workoutTiltle);
        wDuration.setText(workoutDuration);
        String workout_image_url = image_url + workoutImage;

        /* *************************Request an image****************************** */

        ImageRequest imageRequest = new ImageRequest(workout_image_url, new Response.Listener<Bitmap>() {
            @Override
            public void onResponse(Bitmap response) {
                wdetailImage.setImageBitmap(response);
            }
        }, 0, 0, ImageView.ScaleType.FIT_XY, null, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),"something went Wrong",
                        Toast.LENGTH_LONG).show();
                error.printStackTrace();
            }
        });

        mRequestQueue.add(imageRequest);

        /* *************************Request an image****************************** */


                Retrofit retrofit = new Retrofit.Builder().baseUrl(API.exercisesJsonURL)
                        .addConverterFactory(GsonConverterFactory.create()).build();
                API api = retrofit.create(API.class);
                Call<List<exercisesJson>> call = api.getworkouts_exercises();

                call.enqueue(new Callback<List<exercisesJson>>() {
                    @Override
                    public void onResponse(retrofit.Response<List<exercisesJson>> response, Retrofit retrofit) {
                        try {
                            if (response.body() != null) {
                                List<exercisesJson> exercises = response.body();

                                for (int i = 0; i < exercises.size(); i++) {
                                    exercisesJson mworkouts_exercises = new exercisesJson();
                                    mworkouts_exercises.setExercise_id(exercises.get(i).getExercise_id());
                                    mworkouts_exercises.setExercise_equipment(exercises.get(i).getExercise_equipment());
                                    mworkouts_exercises.setExercise_title(exercises.get(i).getExercise_title());
                                    mworkouts_exercises.setExercise_reps(exercises.get(i).getExercise_reps());
                                    mworkouts_exercises.setExercise_dificult(exercises.get(i).getExercise_dificult());
                                    mworkouts_exercises.setExercise_sets(exercises.get(i).getExercise_sets());
                                    mworkouts_exercises.setExercise_steps(exercises.get(i).getExercise_steps());
                                    mworkouts_exercises.setExercise_time(exercises.get(i).getExercise_time());
                                    mworkouts_exercises.setExercise_image(exercises.get(i).getExercise_image());


                                    workouts_exercisesList.add(mworkouts_exercises);
                                }
//                                Toast.makeText(getApplicationContext(), workouts_exercisesList.size(), Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(getApplicationContext(), "exercises does not exist", Toast.LENGTH_SHORT).show();
                            }
                        } catch (Exception e) {
                            Log.d("onResponse", "There is an error");
                            e.printStackTrace();
                        }

                         showProgress(false);
                    }

                    @Override
                    public void onFailure(Throwable t) {
                        t.printStackTrace();
                        showProgress(false);
                    }
                });







/********************************************************/
/*
        Retrofit retrofit2 = new Retrofit.Builder().baseUrl(API.workoutURL)
                .addConverterFactory(GsonConverterFactory.create()).build();
        API api2 = retrofit2.create(API.class);
        Call<List<workouts_exercises>> call2 = api2.getworkouts_exercises();

        call2.enqueue(new Callback<List<workouts_exercises>>() {
            @Override
            public void onResponse(retrofit.Response<List<workouts_exercises>> response, Retrofit retrofit) {
                try {
                    if (response.body() != null) {
                        List<workouts_exercises> works = response.body();

                        for (int i = 0; i < works.size(); i++) {
                            workouts_exercises workouts_exercises = new workouts_exercises();
                            workouts_exercises.setExercise_id(works.get(i).getExercise_id());
                            workouts_exercises.setWorkout_id(works.get(i).getWorkout_id());


                            workouts_exercisesList.add(workouts_exercises);
                        }

                    } else {
                        Toast.makeText(getApplicationContext(), "final exercises does not exist", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Log.d("onResponse", "There is an error");
                    e.printStackTrace();
                }
                for (int i = 0; i < workouts_exercisesList.size(); i++) {
                            if(workouts_exercisesList.get(i).getWorkout_id().equals(workoutId))
                            {
                                filter_workouts_exercisesList.add(workouts_exercisesList.get(i));
                            }
                }

            }

            @Override
            public void onFailure(Throwable t) {
                t.printStackTrace();
            }
        });

*/
/********************************************************/


/*********************** getAllExercises***********************/
/*********************** getAllExercises***********************/

        mRecyclerView.setLayoutManager(new GridLayoutManager(workoutDetailsActivity.this,2));
        workoutDetailsActivity.ActivityAdapter adabter = new
                workoutDetailsActivity.ActivityAdapter(workouts_exercisesList);
        mRecyclerView.setAdapter(adabter);


    }

    public static Intent newIntent(Context packageName, workoutClass workout) {
        Intent intent = new Intent(packageName, workoutDetailsActivity.class);
        intent.putExtra(EXTRA_workout_ID, workout.getWorkout_id());
        intent.putExtra(EXTRA_workout_title, workout.getWorkout_title());
        intent.putExtra(EXTRA_workout_Duration, workout.getWorkout_duration());
        intent.putExtra(EXTRA_workout_difficulty, workout.getWorkout_diffculty());
        intent.putExtra(EXTRA_workout_goals, workout.getWorkout_goals());
        intent.putExtra(EXTRA_workout_description, workout.getWorkout_description());
        intent.putExtra(EXTRA_workout_cover, workout.getWorkout_cover());
        return intent;

    }




    public class ActivityHolder extends RecyclerView.ViewHolder {
        private ImageButton mImageButton1;

        private TextView details1;



        public ActivityHolder(View itemView) {
            super(itemView);
            mImageButton1 = itemView.findViewById(R.id.exercise_Image1);

            details1 = itemView.findViewById(R.id.details1);


        }

        public void bindworkoutActivity(final exercisesJson activity1) {
            details1.setText(activity1.getExercise_sets() + "sets" + "/ " + activity1.getExercise_reps() + "Reps");


            mImageButton1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = ExerciseDetailsActivity.newIntent(getApplicationContext(),activity1);
                    startActivity(i);
                }
            });



            String workou_image_url1 = image_url + activity1.getExercise_image();


            /* *************************Request an image****************************** */

            ImageRequest imageRequest = new ImageRequest(workou_image_url1, new Response.Listener<Bitmap>() {
                @Override
                public void onResponse(Bitmap response) {
                    mImageButton1.setImageBitmap(response);
                }
            }, 0, 0, ImageView.ScaleType.FIT_XY, null, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(),"something went Wrong",
                            Toast.LENGTH_LONG).show();
                    error.printStackTrace();
                }
            });

            mRequestQueue.add(imageRequest);

            /* *************************Request an image****************************** */

        }


    }


    public class ActivityAdapter extends RecyclerView.Adapter<workoutDetailsActivity.ActivityHolder> {
        private List<exercisesJson> exercises;

        public ActivityAdapter(List<exercisesJson> mexercises) {
            exercises = mexercises;
        }

        @Override
        public workoutDetailsActivity.ActivityHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(workoutDetailsActivity.this);
            View v = inflater.inflate(R.layout.workout_exercises, parent, false);
            return new workoutDetailsActivity.ActivityHolder(v);
        }

        @Override
        public void onBindViewHolder(workoutDetailsActivity.ActivityHolder holder, int position) {

                exercisesJson work1 = exercises.get(position);

                holder.bindworkoutActivity(work1);

        }

        @Override
        public int getItemCount() {
            return exercises.size();
        }


    }


    /************************************************************/
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mRecyclerrView.setVisibility(show ? View.GONE : View.VISIBLE);
            mRecyclerrView.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mRecyclerrView.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mRecyclerrView.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }

    /*************************************************************/


}
