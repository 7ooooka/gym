package my.gym;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import my.gym.R;

import java.util.ArrayList;
import java.util.List;

public class equipments_activitiesActivity extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    public static final String EXTRA_equipment_id = "equipment_id";
    public static final String EXTRA_equipment_name = "equipment_name";
    public static final String EXTRA_equipment_thumbnail = "equipment_thumbnail";
    private static final String image_url = "http://fitnessgymapp.000webhostapp.com/ionic/ionic/backend/images/";
    private List<exercisesJson> relatedequipmentsList;
    private equipments_activitiesActivity.ActivityAdapter adabter;
    private RequestQueue mRequestQueue;
    private TextView equipmenTitle;
    private TextView trainerfit;
    private TextView exercisesFooter;
    private TextView workoutsFooter;
    private TextView storeFooter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_equipments_activities);
        mRequestQueue = Volley.newRequestQueue(getApplicationContext());
        mRecyclerView = findViewById(R.id.equipmentsRecycler);
        relatedequipmentsList = new ArrayList<>();
        equipmenTitle =  findViewById(R.id.eqTitle);

        trainerfit = findViewById(R.id.trainerfit);
        exercisesFooter = findViewById(R.id.exercises);
        workoutsFooter = findViewById(R.id.workoutsFooter);
        storeFooter = findViewById(R.id.store);
        trainerfit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(equipments_activitiesActivity.this,mainPage.class);
                startActivity(i);

            }
        });
        exercisesFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(equipments_activitiesActivity.this,ExercisesActivity.class);
                startActivity(i);

            }
        });
        workoutsFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(equipments_activitiesActivity.this,workoutsActivity.class);
                startActivity(i);

            }
        });
        storeFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(equipments_activitiesActivity.this,StoreActivity.class);
                startActivity(i);

            }
        });


        equipmenTitle.setText(getIntent().getStringExtra(EXTRA_equipment_name));
        String equipment_id = getIntent().getStringExtra(EXTRA_equipment_id);

        for (int i=0 ;i< ExercisesActivity.exercisesList.size();i++)
        {
            if (ExercisesActivity.exercisesList.get(i).getExercise_equipment().equals(equipment_id))
            {
                relatedequipmentsList.add(ExercisesActivity.exercisesList.get(i));
            }
        }
        mRecyclerView.setLayoutManager(new GridLayoutManager(equipments_activitiesActivity.this,2));
        adabter = new equipments_activitiesActivity.ActivityAdapter(relatedequipmentsList);
        mRecyclerView.setAdapter(adabter);
        adabter.notifyDataSetChanged();
        Toast.makeText(getApplicationContext(),String.valueOf(relatedequipmentsList.size()),Toast.LENGTH_LONG).show();
    }


    public static Intent newIntent(Context packageName, equipment equipment) {
        Intent intent = new Intent(packageName, equipments_activitiesActivity.class);
        intent.putExtra(EXTRA_equipment_id, equipment.getEquipment_id());
        intent.putExtra(EXTRA_equipment_name, equipment.getEquipment_name());
        intent.putExtra(EXTRA_equipment_thumbnail, equipment.getEquipment_thumbnail());

        return intent;

    }

    public class ActivityHolder extends RecyclerView.ViewHolder {
        private ImageButton mImageButton1;
        private ImageButton mImageButton2;
        private TextView details1;
        private TextView details2;


        public ActivityHolder(View itemView) {
            super(itemView);
            mImageButton1 = itemView.findViewById(R.id.exercise_Image1);
            details1 = itemView.findViewById(R.id.details1);

        }

        public void bindworkoutActivity(final exercisesJson activity1) {
            details1.setText(activity1.getExercise_title());



            mImageButton1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = ExerciseDetailsActivity.newIntent(getApplicationContext(),activity1);
                    startActivity(i);
                }
            });



            String workou_image_url1 = image_url + activity1.getExercise_image();


            /* *************************Request an image****************************** */

            ImageRequest imageRequest = new ImageRequest(workou_image_url1, new Response.Listener<Bitmap>() {
                @Override
                public void onResponse(Bitmap response) {
                    mImageButton1.setImageBitmap(response);
                }
            }, 0, 0, ImageView.ScaleType.FIT_XY, null, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(),"something went Wrong",
                            Toast.LENGTH_LONG).show();
                    error.printStackTrace();
                }
            });

            mRequestQueue.add(imageRequest);

            /* *************************Request an image****************************** */

        }


    }

    public class ActivityAdapter extends RecyclerView.Adapter<equipments_activitiesActivity.ActivityHolder> {
        private List<exercisesJson> exercises;

        public ActivityAdapter(List<exercisesJson> mexercises) {
            exercises = mexercises;
        }

        @Override
        public equipments_activitiesActivity.ActivityHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(equipments_activitiesActivity.this);
            View v = inflater.inflate(R.layout.workout_exercises, parent, false);
            return new equipments_activitiesActivity.ActivityHolder(v);
        }

        @Override
        public void onBindViewHolder(equipments_activitiesActivity.ActivityHolder holder, int position) {

                exercisesJson work1 = exercises.get(position);
                holder.bindworkoutActivity(work1);

        }

        @Override
        public int getItemCount() {
            return exercises.size();
        }




    }
}
