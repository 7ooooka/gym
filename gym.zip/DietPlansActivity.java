package my.gym;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import my.gym.R;

import java.util.ArrayList;
import java.util.List;

import retrofit.Call;
import retrofit.Callback;
import retrofit.GsonConverterFactory;
import retrofit.Retrofit;

public class DietPlansActivity extends AppCompatActivity {
private RecyclerView DietsRecyclerView;
    public static List<DietPlan> DietssList;
    private static final String image_url = "http://fitnessgymapp.000webhostapp.com/ionic/ionic/backend/images/";
    private RequestQueue mRequestQueue;
    private View mRecyclerrView;
    private View mProgressView;
    private Button btnMuscle;
    private Button btnFat;
    private Button btnTransform;
    private TextView trainerfit;
    private TextView exercisesFooter;
    private TextView workoutsFooter;
    private TextView storeFooter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diet_plans);
        mRecyclerrView = findViewById(R.id.dietPlansActivity);
        mProgressView = findViewById(R.id.login_progress);
        DietsRecyclerView = findViewById(R.id.DietsRecyclerView);
        btnMuscle = findViewById(R.id.btnmuscle);
        btnFat = findViewById(R.id.btnfat);
        btnTransform = findViewById(R.id.btntransform);

        trainerfit = findViewById(R.id.trainerfit);
        exercisesFooter = findViewById(R.id.exercises);
        workoutsFooter = findViewById(R.id.workoutsFooter);
        storeFooter = findViewById(R.id.store);
        trainerfit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(DietPlansActivity.this,mainPage.class);
                startActivity(i);

            }
        });
        exercisesFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(DietPlansActivity.this,ExercisesActivity.class);
                startActivity(i);

            }
        });
        workoutsFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(DietPlansActivity.this,workoutsActivity.class);
                startActivity(i);

            }
        });
        storeFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(DietPlansActivity.this,StoreActivity.class);
                startActivity(i);

            }
        });



        btnMuscle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(DietPlansActivity.this,DietKindsActivity.class);
                startActivity(i);
            }
        });

        btnFat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(DietPlansActivity.this,LostFatActivity.class);
                startActivity(i);
            }
        });

        btnTransform.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(DietPlansActivity.this,TransformActivity.class);
                startActivity(i);
            }
        });
        DietssList = new ArrayList<>();
        mRequestQueue = Volley.newRequestQueue(getApplicationContext());
        Retrofit retrofit = new Retrofit.Builder().baseUrl(API.DietsURL)
                .addConverterFactory(GsonConverterFactory.create()).build();
        API api = retrofit.create(API.class);
        Call<List<DietPlan>> call = api.getDiets();
        showProgress(true);
        call.enqueue(new Callback<List<DietPlan>>() {
            @Override
            public void onResponse(retrofit.Response<List<DietPlan>> response, Retrofit retrofit) {
                try {
                    if(response.body()!=null)
                    {
                        List<DietPlan> diets = response.body();

                        for (int i = 0; i < diets.size(); i++) {
                            DietPlan Diet = new DietPlan();
                            Diet.setId(diets.get(i).getId());
                            Diet.setDiet_type(diets.get(i).getDiet_type());
                            Diet.setDiet_title(diets.get(i).getDiet_title());
                            Diet.setDiet_description(diets.get(i).getDiet_description());
                            Diet.setDiet_list(diets.get(i).getDiet_list());
                            Diet.setDiet_image(diets.get(i).getDiet_image());
                            Diet.setDiet_calories(diets.get(i).getDiet_calories());
                            Diet.setDiet_carbs(diets.get(i).getDiet_carbs());
                            Diet.setDiet_protein(diets.get(i).getDiet_protein());
                            Diet.setDiet_fat(diets.get(i).getDiet_fat());
                            DietssList.add(Diet);
                        }

                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "Diets does not exist", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Log.d("onResponse", "There is an error");
                    e.printStackTrace();
                }
                showProgress(false);
            }
            @Override
            public void onFailure(Throwable t) {
                t.printStackTrace();
                showProgress(false);
            }
        });

        DietsRecyclerView.setLayoutManager(new LinearLayoutManager(DietPlansActivity.this));
        DietPlansActivity.ActivityAdapter adabter = new DietPlansActivity.ActivityAdapter(DietssList);
        DietsRecyclerView.setAdapter(adabter);


    }


    public class ActivityHolder extends RecyclerView.ViewHolder {
        private ImageView dietImage;
        private TextView dietTitle;
        private TextView dietType;


        public ActivityHolder(View itemView) {
            super(itemView);
            dietImage = itemView.findViewById(R.id.dietImage);
            dietTitle = itemView.findViewById(R.id.dietTiltle);
            dietType = itemView.findViewById(R.id.dietType);

        }

        public void bindDiets(DietPlan diet) {

      dietTitle.setText(diet.getDiet_title());
      dietType.setText(diet.getDiet_type());
            String diet_image_url = image_url + diet.getDiet_image();
            /* *************************Request an image****************************** */

            ImageRequest imageRequest = new ImageRequest(diet_image_url, new Response.Listener<Bitmap>() {
                @Override
                public void onResponse(Bitmap response) {
                    dietImage.setImageBitmap(response);
                }
            }, 0, 0, ImageView.ScaleType.FIT_XY, null, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(),"something went Wrong",
                            Toast.LENGTH_LONG).show();
                    error.printStackTrace();
                }
            });

            mRequestQueue.add(imageRequest);

            /* *************************Request an image****************************** */


        }



    }



    public class ActivityAdapter extends RecyclerView.Adapter<DietPlansActivity.ActivityHolder> {

        private List<DietPlan> Diets;
        public ActivityAdapter(List<DietPlan> Dietss) {
            Diets = Dietss;
        }

        @Override
        public DietPlansActivity.ActivityHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(DietPlansActivity.this);
            View v = inflater.inflate(R.layout.diets_item, parent, false);

            return new DietPlansActivity.ActivityHolder(v);
        }

        @Override
        public void onBindViewHolder(DietPlansActivity.ActivityHolder holder, int position) {
            final DietPlan diet = Diets.get(position);
            holder.bindDiets(diet);
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = DietDetailsActivity.newIntent(getApplicationContext(),diet);
                    startActivity(i);


                }
            });
        }

        @Override
        public int getItemCount() {
            return Diets.size();
        }
    }

    /************************************************************/
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mRecyclerrView.setVisibility(show ? View.GONE : View.VISIBLE);
            mRecyclerrView.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mRecyclerrView.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mRecyclerrView.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }

    /*************************************************************/


}
