package my.gym;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import my.gym.R;

import java.util.ArrayList;
import java.util.List;

import retrofit.Call;
import retrofit.Callback;
import retrofit.GsonConverterFactory;
import retrofit.Retrofit;

public class BodybartsActivity extends AppCompatActivity {
    private List<bodyParts> muscles;
    private RequestQueue mRequestQueue;
    private static final String image_url = "http://fitnessgymapp.000webhostapp.com/ionic/ionic/backend/images/";
    private RecyclerView mRecyclerView;

    private View mRecyclerrView;
    private View mProgressView;

    private TextView trainerfit;
    private TextView exercisesFooter;
    private TextView workoutsFooter;
    private TextView storeFooter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bodybarts);
        mRecyclerrView = findViewById(R.id.categsss);
        mProgressView = findViewById(R.id.login_progress);

        trainerfit = findViewById(R.id.trainerfit);
        exercisesFooter = findViewById(R.id.exercises);
        workoutsFooter = findViewById(R.id.workoutsFooter);
        storeFooter = findViewById(R.id.store);
        trainerfit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(BodybartsActivity.this,mainPage.class);
                startActivity(i);

            }
        });
        exercisesFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(BodybartsActivity.this,ExercisesActivity.class);
                startActivity(i);

            }
        });
        workoutsFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(BodybartsActivity.this,workoutsActivity.class);
                startActivity(i);

            }
        });
        storeFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(BodybartsActivity.this,StoreActivity.class);
                startActivity(i);

            }
        });
        mRecyclerView = findViewById(R.id.categoriess);
        mRequestQueue = Volley.newRequestQueue(getApplicationContext());
        muscles = new ArrayList<>();

        Retrofit retrofit = new Retrofit.Builder().baseUrl(API.workoutURL)
                .addConverterFactory(GsonConverterFactory.create()).build();
        API api = retrofit.create(API.class);
        Call<List<bodyParts>> call = api.getBodyBarts();
        showProgress(true);
        call.enqueue(new Callback<List<bodyParts>>() {
            @Override
            public void onResponse(retrofit.Response<List<bodyParts>> response, Retrofit retrofit) {
                try {
                    if(response.body()!=null)
                    {
                        List<bodyParts> works = response.body();

                        for (int i = 0; i < works.size(); i++) {
                            bodyParts bodyParts = new bodyParts();
                            bodyParts.setBodypart_id(works.get(i).getBodypart_id());
                            bodyParts.setBodypart_name(works.get(i).getBodypart_name());
                            bodyParts.setBodypart_thumbnail(works.get(i).getBodypart_thumbnail());

                            muscles.add(bodyParts);
                        }

                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "muscles does not exist", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Log.d("onResponse", "There is an error");
                    e.printStackTrace();
                }
                showProgress(false);
            }
            @Override
            public void onFailure(Throwable t) {
                t.printStackTrace();
                showProgress(false);
            }
        });

        mRecyclerView.setLayoutManager(new GridLayoutManager(BodybartsActivity.this,3));
        BodybartsActivity.ActivityAdapter adabter = new BodybartsActivity.ActivityAdapter(muscles);
        mRecyclerView.setAdapter(adabter);
    }

    public class ActivityHolder extends RecyclerView.ViewHolder {
        private ImageView muscleimage;
        private TextView muscletiltle;



        public ActivityHolder(View itemView) {
            super(itemView);
            muscleimage = itemView.findViewById(R.id.muscleImage);
            muscletiltle = itemView.findViewById(R.id.muscleTiltle);


        }

        public void bindworkout(final bodyParts activity) {

            muscleimage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = bodyparExercisesActivity.newIntent(getApplicationContext(),activity);
                    startActivity(i);
                }
            });
            //  Toast.makeText(getApplicationContext(),  activity.getWorkout_id() , Toast.LENGTH_SHORT).show();

            muscletiltle.setText(activity.getBodypart_name());

            String workou_image_url = image_url + activity.getBodypart_thumbnail();

            /* *************************Request an image****************************** */

            ImageRequest imageRequest = new ImageRequest(workou_image_url, new Response.Listener<Bitmap>() {
                @Override
                public void onResponse(Bitmap response) {
                    muscleimage.setImageBitmap(response);
                }
            }, 0, 0, ImageView.ScaleType.FIT_XY, null, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(),"something went Wrong",
                            Toast.LENGTH_LONG).show();
                    error.printStackTrace();
                }
            });

            mRequestQueue.add(imageRequest);

            /* *************************Request an image****************************** */

        }


    }

    public class ActivityAdapter extends RecyclerView.Adapter<BodybartsActivity.ActivityHolder> {

        private List<bodyParts> workouts;
        public ActivityAdapter(List<bodyParts> workoutss) {
            workouts = workoutss;
        }

        @Override
        public BodybartsActivity.ActivityHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(BodybartsActivity.this);
            View v = inflater.inflate(R.layout.bodtparts, parent, false);

            return new BodybartsActivity.ActivityHolder(v);
        }

        @Override
        public void onBindViewHolder(BodybartsActivity.ActivityHolder holder, int position) {
            final bodyParts work = workouts.get(position);
            holder.bindworkout(work);

            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
/*

                    Intent i = workoutDetailsActivity.newIntent(getApplicationContext(),work);
                    startActivity(i);
*/

                }
            });
        }

        @Override
        public int getItemCount() {
            return workouts.size();
        }
    }




    /************************************************************/
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mRecyclerrView.setVisibility(show ? View.GONE : View.VISIBLE);
            mRecyclerrView.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mRecyclerrView.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mRecyclerrView.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }

    /*************************************************************/




}
