package my.gym;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import my.gym.R;

import java.util.ArrayList;
import java.util.List;

public class CalculatorActivity extends AppCompatActivity {
    private TextView trainerfit;
    private TextView exercisesFooter;
    private TextView workoutsFooter;
    private TextView storeFooter;
    private Spinner sort_by_spinner;
    private Spinner sort_by_spinner1;
    private EditText age;
    private EditText height;
    private EditText weight;
    private TextView bmrText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);
        age = findViewById(R.id.age);
        height = findViewById(R.id.height);
        weight = findViewById(R.id.weight);
        bmrText = findViewById(R.id.bmrText);
        weight.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!age.getText().toString().matches("") && !height.getText().toString().matches("")
                        && !weight.getText().toString().matches("")) {
                    if (Integer.parseInt(age.getText().toString()) > 15 && Integer.parseInt(height.getText().toString()) > 100
                            && Integer.parseInt(weight.getText().toString()) > 60) {
                        bmrText.setText("270");
                    }
                    else {
                        bmrText.setText("");
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        trainerfit = findViewById(R.id.trainerfit);
        exercisesFooter = findViewById(R.id.exercises);
        workoutsFooter = findViewById(R.id.workoutsFooter);
        storeFooter = findViewById(R.id.store);
        sort_by_spinner = findViewById(R.id.sort_by_spinner);
        sort_by_spinner1 = findViewById(R.id.sort_by_spinner1);
        List<String> GenderSpinnerlist = new ArrayList<String>();
        List<String> ActivitySpinnerlist = new ArrayList<String>();
        GenderSpinnerlist.add("Male");
        GenderSpinnerlist.add("Female");
        ActivitySpinnerlist.add("Sedentary-Little or no exercise");
        ActivitySpinnerlist.add("Lightly - 1-3 Times/Week");
        ActivitySpinnerlist.add("Moderatetely- 3-5 Times/week");
        ActivitySpinnerlist.add("Very - 6-7 Times/week");

        ArrayAdapter<String> ActivitySpinneradapter = new ArrayAdapter<String>(CalculatorActivity.this, android.R.layout.simple_expandable_list_item_1,
                ActivitySpinnerlist);
        ActivitySpinneradapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        ArrayAdapter<String> GenderSpinneradapter = new ArrayAdapter<String>(CalculatorActivity.this, android.R.layout.simple_expandable_list_item_1,
                GenderSpinnerlist);
        GenderSpinneradapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sort_by_spinner.setAdapter(GenderSpinneradapter);
        sort_by_spinner1.setAdapter(ActivitySpinneradapter);
        trainerfit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(CalculatorActivity.this, mainPage.class);

                startActivity(i);

            }
        });
        exercisesFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(CalculatorActivity.this, ExercisesActivity.class);
                startActivity(i);

            }
        });
        workoutsFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(CalculatorActivity.this, workoutsActivity.class);
                startActivity(i);

            }
        });
        storeFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(CalculatorActivity.this, StoreActivity.class);
                startActivity(i);

            }
        });

    }
}
