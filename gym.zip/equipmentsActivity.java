package my.gym;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import my.gym.R;

import java.util.ArrayList;
import java.util.List;

import retrofit.Call;
import retrofit.Callback;
import retrofit.GsonConverterFactory;
import retrofit.Retrofit;

public class equipmentsActivity extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private static final String image_url = "http://fitnessgymapp.000webhostapp.com/ionic/ionic/backend/images/";
    private List<equipment> equipmentsList;
    private RequestQueue mRequestQueue;
    private View mRecyclerrView;
    private View mProgressView;
    private TextView trainerfit;
    private TextView exercisesFooter;
    private TextView workoutsFooter;
    private TextView storeFooter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_equipments);

        mRecyclerrView = findViewById(R.id.eques);
        mProgressView = findViewById(R.id.login_progress);
        mRecyclerView = findViewById(R.id.equipments);
        equipmentsList = new ArrayList<>();
        mRequestQueue = Volley.newRequestQueue(getApplicationContext());
        trainerfit = findViewById(R.id.trainerfit);
        exercisesFooter = findViewById(R.id.exercises);
        workoutsFooter = findViewById(R.id.workoutsFooter);
        storeFooter = findViewById(R.id.store);
        trainerfit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(equipmentsActivity.this,mainPage.class);
                startActivity(i);

            }
        });
        exercisesFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(equipmentsActivity.this,ExercisesActivity.class);
                startActivity(i);

            }
        });
        workoutsFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(equipmentsActivity.this,workoutsActivity.class);
                startActivity(i);

            }
        });
        storeFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(equipmentsActivity.this,StoreActivity.class);
                startActivity(i);

            }
        });
        Retrofit retrofit = new Retrofit.Builder().baseUrl(API.workoutURL)
                .addConverterFactory(GsonConverterFactory.create()).build();
        API api = retrofit.create(API.class);
        Call<List<equipment>> call = api.getEquipments();
        showProgress(true);
        call.enqueue(new Callback<List<equipment>>() {
            @Override
            public void onResponse(retrofit.Response<List<equipment>> response, Retrofit retrofit) {
                try {
                    if(response.body()!=null)
                    {
                        List<equipment> equipments = response.body();

                        for (int i = 0; i < equipments.size(); i++) {
                            equipment equipment = new equipment();

                            equipment.setEquipment_id(equipments.get(i).getEquipment_id());
                            equipment.setEquipment_name(equipments.get(i).getEquipment_name());
                            equipment.setEquipment_thumbnail(equipments.get(i).getEquipment_thumbnail());
                            equipmentsList.add(equipment);
                        }
                        Toast.makeText(getApplicationContext(),String.valueOf(equipmentsList.size()),Toast.LENGTH_LONG).show();
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "equipments does not exist", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Log.d("onResponse", "There is an error");
                    e.printStackTrace();
                }
                showProgress(false);
            }
            @Override
            public void onFailure(Throwable t) {
                t.printStackTrace();
                showProgress(false);
            }
        });

        mRecyclerView.setLayoutManager(new GridLayoutManager(equipmentsActivity.this,3));
        equipmentsActivity.ActivityAdapter adabter = new equipmentsActivity.ActivityAdapter(equipmentsList);
        mRecyclerView.setAdapter(adabter);

    }







    public class ActivityHolder extends RecyclerView.ViewHolder {
        private ImageButton image1;

        private TextView txt1;




        public ActivityHolder(View itemView) {
            super(itemView);
            image1 = itemView.findViewById(R.id.muscleImage);
            txt1 = itemView.findViewById(R.id.muscleTiltle);


        }

        public void bindProduct(final equipment equipment) {


            txt1.setText(equipment.getEquipment_name());

            image1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    Intent i = equipments_activitiesActivity.newIntent(getApplicationContext(),equipment);
                    startActivity(i);
                }
            });

            String category_image_url1 = image_url + equipment.getEquipment_thumbnail();


            /* *************************Request an image1****************************** */

            ImageRequest imageRequest = new ImageRequest(category_image_url1, new Response.Listener<Bitmap>() {
                @Override
                public void onResponse(Bitmap response) {
                    image1.setImageBitmap(response);
                }
            }, 0, 0, ImageView.ScaleType.FIT_XY, null, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(),"something went Wrong",
                            Toast.LENGTH_LONG).show();
                    error.printStackTrace();
                }
            });

            mRequestQueue.add(imageRequest);

            /* *************************Request an image1****************************** */



        }


    }



    public class ActivityAdapter extends RecyclerView.Adapter<equipmentsActivity.ActivityHolder> {

        private List<equipment> equipments;
        public ActivityAdapter(List<equipment> mequipments) {
            equipments = mequipments;
        }

        @Override
        public equipmentsActivity.ActivityHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(equipmentsActivity.this);
            View v = inflater.inflate(R.layout.bodtparts, parent, false);

            return new equipmentsActivity.ActivityHolder(v);
        }

        @Override
        public void onBindViewHolder(equipmentsActivity.ActivityHolder holder, int position) {

            equipment equipment = equipments.get(position);

            holder.bindProduct(equipment);


        }

        @Override
        public int getItemCount() {
            return equipments.size();
        }
    }


    /************************************************************/
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mRecyclerrView.setVisibility(show ? View.GONE : View.VISIBLE);
            mRecyclerrView.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mRecyclerrView.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mRecyclerrView.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }

    /*************************************************************/





}
