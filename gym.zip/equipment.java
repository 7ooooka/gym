package my.gym;

public class equipment {


    private String equipment_id;
    private String equipment_name;
    private String equipment_thumbnail;

    public String getEquipment_id() {
        return equipment_id;
    }

    public void setEquipment_id(String equipment_id) {
        this.equipment_id = equipment_id;
    }

    public String getEquipment_name() {
        return equipment_name;
    }

    public void setEquipment_name(String equipment_name) {
        this.equipment_name = equipment_name;
    }

    public String getEquipment_thumbnail() {
        return equipment_thumbnail;
    }

    public void setEquipment_thumbnail(String equipment_thumbnail) {
        this.equipment_thumbnail = equipment_thumbnail;
    }
}
