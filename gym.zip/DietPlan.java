package my.gym;

public class DietPlan {

    private String id;
    private String diet_type;
    private String diet_title;
    private String diet_description;
    private String diet_list;
    private String diet_image;
    private String diet_calories;
    private String diet_carbs;
    private String diet_protein;
    private String diet_fat;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDiet_type() {
        return diet_type;
    }

    public void setDiet_type(String diet_type) {
        this.diet_type = diet_type;
    }

    public String getDiet_title() {
        return diet_title;
    }

    public void setDiet_title(String diet_title) {
        this.diet_title = diet_title;
    }

    public String getDiet_description() {
        return diet_description;
    }

    public void setDiet_description(String diet_description) {
        this.diet_description = diet_description;
    }

    public String getDiet_list() {
        return diet_list;
    }

    public void setDiet_list(String diet_list) {
        this.diet_list = diet_list;
    }

    public String getDiet_image() {
        return diet_image;
    }

    public void setDiet_image(String diet_image) {
        this.diet_image = diet_image;
    }

    public String getDiet_calories() {
        return diet_calories;
    }

    public void setDiet_calories(String diet_calories) {
        this.diet_calories = diet_calories;
    }

    public String getDiet_carbs() {
        return diet_carbs;
    }

    public void setDiet_carbs(String diet_carbs) {
        this.diet_carbs = diet_carbs;
    }

    public String getDiet_protein() {
        return diet_protein;
    }

    public void setDiet_protein(String diet_protein) {
        this.diet_protein = diet_protein;
    }

    public String getDiet_fat() {
        return diet_fat;
    }

    public void setDiet_fat(String diet_fat) {
        this.diet_fat = diet_fat;
    }
}
