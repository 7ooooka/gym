package my.gym;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import my.gym.R;

import java.util.ArrayList;
import java.util.List;

import retrofit.Call;
import retrofit.Callback;
import retrofit.GsonConverterFactory;
import retrofit.Retrofit;

public class ExercisesActivity extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private static final String image_url = "http://fitnessgymapp.000webhostapp.com/ionic/ionic/backend/images/";
    public static List<exercisesJson> exercisesList;
    private RequestQueue mRequestQueue;
    private ExercisesActivity.ActivityAdapter adabter;
    private View mRecyclerrView;
    private View mProgressView;
    private Button b1;
    private Button b2;
    private TextView trainerfit;
    private TextView exercisesFooter;
    private TextView workoutsFooter;
    private TextView storeFooter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercises);
        mRecyclerView = findViewById(R.id.exercisesRecycler);
        mRecyclerrView = findViewById(R.id.exerciseActivity);
        mProgressView = findViewById(R.id.login_progress);
        b1 = findViewById(R.id.btnmuscle);
        b2 = findViewById(R.id.button3);

        exercisesList = new ArrayList<>();
        mRequestQueue = Volley.newRequestQueue(getApplicationContext());

        trainerfit = findViewById(R.id.trainerfit);
        exercisesFooter = findViewById(R.id.exercises);
        workoutsFooter = findViewById(R.id.workoutsFooter);
        storeFooter = findViewById(R.id.store);
        trainerfit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ExercisesActivity.this,mainPage.class);
                startActivity(i);

            }
        });
        exercisesFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ExercisesActivity.this,ExercisesActivity.class);
                startActivity(i);

            }
        });
        workoutsFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ExercisesActivity.this,workoutsActivity.class);
                startActivity(i);

            }
        });
        storeFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ExercisesActivity.this,StoreActivity.class);
                startActivity(i);

            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ExercisesActivity.this,BodybartsActivity.class);
                startActivity(i);
            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ExercisesActivity.this,equipmentsActivity.class);
                startActivity(i);
            }
        });

        Retrofit retrofit = new Retrofit.Builder().baseUrl(API.workoutURL)
                .addConverterFactory(GsonConverterFactory.create()).build();
        API api = retrofit.create(API.class);
        Call<List<exercisesJson>> call = api.getAllExercises();
        showProgress(true);
        call.enqueue(new Callback<List<exercisesJson>>() {
            @Override
            public void onResponse(retrofit.Response<List<exercisesJson>> response, Retrofit retrofit) {
                try {
                    if(response.body()!=null)
                    {
                        List<exercisesJson> exercises = response.body();

                        for (int i = 0; i < exercises.size(); i++) {
                            exercisesJson exercise = new exercisesJson();
                            exercise.setExercise_id(exercises.get(i).getExercise_id());
                            exercise.setExercise_equipment(exercises.get(i).getExercise_equipment());
                            exercise.setExercise_title(exercises.get(i).getExercise_title());
                            exercise.setExercise_reps(exercises.get(i).getExercise_reps());
                            exercise.setExercise_dificult(exercises.get(i).getExercise_dificult());
                            exercise.setExercise_sets(exercises.get(i).getExercise_sets());
                            exercise.setExercise_steps(exercises.get(i).getExercise_steps());
                            exercise.setExercise_time(exercises.get(i).getExercise_time());
                            exercise.setExercise_image(exercises.get(i).getExercise_image());
                            exercisesList.add(exercise);
                        }

                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "All exercises does not exist", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Log.d("onResponse", "There is an error");
                    e.printStackTrace();
                }

                showProgress(false);
            }
            @Override
            public void onFailure(Throwable t) {
                t.printStackTrace();
                showProgress(false);
                Toast.makeText(getApplicationContext(), "errror", Toast.LENGTH_SHORT).show();
            }
        });
        mRecyclerView.setLayoutManager(new GridLayoutManager(ExercisesActivity.this,2));
         adabter = new ExercisesActivity.ActivityAdapter(exercisesList);
        mRecyclerView.setAdapter(adabter);
        adabter.notifyDataSetChanged();
    }
    @Override
    public void onResume(){
        super.onResume();
        adabter.notifyDataSetChanged();

    }

    public class ActivityHolder extends RecyclerView.ViewHolder {
        private ImageButton mImageButton1;

        private TextView details1;



        public ActivityHolder(View itemView) {
            super(itemView);
            mImageButton1 = itemView.findViewById(R.id.exercise_Image1);

            details1 = itemView.findViewById(R.id.details1);


        }

        public void bindworkoutActivity(final exercisesJson activity1) {
            details1.setText(activity1.getExercise_title());



            mImageButton1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = ExerciseDetailsActivity.newIntent(getApplicationContext(),activity1);
                    startActivity(i);
                }
            });



            String workou_image_url1 = image_url + activity1.getExercise_image();

            /* *************************Request an image****************************** */

            ImageRequest imageRequest = new ImageRequest(workou_image_url1, new Response.Listener<Bitmap>() {
                @Override
                public void onResponse(Bitmap response) {
                    mImageButton1.setImageBitmap(response);
                }
            }, 0, 0, ImageView.ScaleType.FIT_XY, null, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(),"something went Wrong",
                            Toast.LENGTH_LONG).show();
                    error.printStackTrace();
                }
            });

            mRequestQueue.add(imageRequest);

            /* *************************Request an image****************************** */

        }


    }

    public class ActivityAdapter extends RecyclerView.Adapter<ExercisesActivity.ActivityHolder> {
        private List<exercisesJson> exercises;

        public ActivityAdapter(List<exercisesJson> mexercises) {
            exercises = mexercises;
        }

        @Override
        public ExercisesActivity.ActivityHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(ExercisesActivity.this);
            View v = inflater.inflate(R.layout.workout_exercises, parent, false);
            return new ExercisesActivity.ActivityHolder(v);
        }

        @Override
        public void onBindViewHolder(ExercisesActivity.ActivityHolder holder, int position) {
                exercisesJson work1 = exercises.get(position);

                holder.bindworkoutActivity(work1);

        }

        @Override
        public int getItemCount() {
            return exercises.size();
        }




    }

    /************************************************************/
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mRecyclerrView.setVisibility(show ? View.GONE : View.VISIBLE);
            mRecyclerrView.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mRecyclerrView.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mRecyclerrView.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }

    /*************************************************************/
}
