package my.gym;

public class exercisesJson {
    private String 	exercise_id;
    private String 	exercise_equipment;
    private String 	exercise_title;
    private String 	exercise_reps;
    private String 	exercise_dificult;
    private String 	exercise_sets;
    private String 	exercise_steps;
    private String 	exercise_time;
    private String 	exercise_image;

    public String getExercise_id() {
        return exercise_id;
    }

    public void setExercise_id(String exercise_id) {
        this.exercise_id = exercise_id;
    }

    public String getExercise_equipment() {
        return exercise_equipment;
    }

    public void setExercise_equipment(String exercise_equipment) {
        this.exercise_equipment = exercise_equipment;
    }

    public String getExercise_title() {
        return exercise_title;
    }

    public void setExercise_title(String exercise_title) {
        this.exercise_title = exercise_title;
    }

    public String getExercise_reps() {
        return exercise_reps;
    }

    public void setExercise_reps(String exercise_reps) {
        this.exercise_reps = exercise_reps;
    }

    public String getExercise_dificult() {
        return exercise_dificult;
    }

    public void setExercise_dificult(String exercise_dificult) {
        this.exercise_dificult = exercise_dificult;
    }

    public String getExercise_sets() {
        return exercise_sets;
    }

    public void setExercise_sets(String exercise_sets) {
        this.exercise_sets = exercise_sets;
    }

    public String getExercise_steps() {
        return exercise_steps;
    }

    public void setExercise_steps(String exercise_steps) {
        this.exercise_steps = exercise_steps;
    }

    public String getExercise_time() {
        return exercise_time;
    }

    public void setExercise_time(String exercise_time) {
        this.exercise_time = exercise_time;
    }

    public String getExercise_image() {
        return exercise_image;
    }

    public void setExercise_image(String exercise_image) {
        this.exercise_image = exercise_image;
    }
}
