package my.gym;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import my.gym.R;

import java.util.ArrayList;
import java.util.List;

import retrofit.Call;
import retrofit.Callback;
import retrofit.GsonConverterFactory;
import retrofit.Retrofit;

public class categoriesActivity extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private static final String image_url = "http://fitnessgymapp.000webhostapp.com/ionic/ionic/backend/images/";
    private List<category_product> categoriesist;
    private RequestQueue mRequestQueue;
    private View mRecyclerrView;
    private View mProgressView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categories);

        mRecyclerrView = findViewById(R.id.categs);
        mProgressView = findViewById(R.id.login_progress);
        mRecyclerView = findViewById(R.id.categories);
        categoriesist = new ArrayList<>();
        mRequestQueue = Volley.newRequestQueue(getApplicationContext());

        Retrofit retrofit = new Retrofit.Builder().baseUrl(API.workoutURL)
                .addConverterFactory(GsonConverterFactory.create()).build();
        API api = retrofit.create(API.class);
        Call<List<category_product>> call = api.getcategories_products();
        showProgress(true);
        call.enqueue(new Callback<List<category_product>>() {
            @Override
            public void onResponse(retrofit.Response<List<category_product>> response, Retrofit retrofit) {
                try {
                    if(response.body()!=null)
                    {
                        List<category_product> categories = response.body();

                        for (int i = 0; i < categories.size(); i++) {
                            category_product category = new category_product();

                            category.setCategories_products_id(categories.get(i).getCategories_products_id());
                            category.setCategories_products_title(categories.get(i).getCategories_products_title());
                            category.setCategories_products_image(categories.get(i).getCategories_products_image());
                            categoriesist.add(category);
                        }
                        Toast.makeText(getApplicationContext(),String.valueOf(categoriesist.size()),Toast.LENGTH_LONG).show();
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "products does not exist", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Log.d("onResponse", "There is an error");
                    e.printStackTrace();
                }
                showProgress(false);
            }
            @Override
            public void onFailure(Throwable t) {
                t.printStackTrace();
                showProgress(false);
            }
        });

        mRecyclerView.setLayoutManager(new GridLayoutManager(categoriesActivity.this,3));
        categoriesActivity.ActivityAdapter adabter = new categoriesActivity.ActivityAdapter(categoriesist);
        mRecyclerView.setAdapter(adabter);

    }







    public class ActivityHolder extends RecyclerView.ViewHolder {
        private ImageButton image1;

        private TextView txt1;




        public ActivityHolder(View itemView) {
            super(itemView);
            image1 = itemView.findViewById(R.id.img1);
            txt1 = itemView.findViewById(R.id.txt1);


        }

        public void bindProduct(final category_product mProduct1) {


            txt1.setText(mProduct1.getCategories_products_title());

            image1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    Intent i = categoryProductsActivity.newIntent(getApplicationContext(),mProduct1);
                    startActivity(i);
                }
            });

            String category_image_url1 = image_url + mProduct1.getCategories_products_image();


            /* *************************Request an image1****************************** */

            ImageRequest imageRequest = new ImageRequest(category_image_url1, new Response.Listener<Bitmap>() {
                @Override
                public void onResponse(Bitmap response) {
                    image1.setImageBitmap(response);
                }
            }, 0, 0, ImageView.ScaleType.FIT_XY, null, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(),"something went Wrong",
                            Toast.LENGTH_LONG).show();
                    error.printStackTrace();
                }
            });

            mRequestQueue.add(imageRequest);

            /* *************************Request an image1****************************** */



        }


    }



    public class ActivityAdapter extends RecyclerView.Adapter<categoriesActivity.ActivityHolder> {

        private List<category_product> products;
        public ActivityAdapter(List<category_product> mproducts) {
            products = mproducts;
        }

        @Override
        public categoriesActivity.ActivityHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(categoriesActivity.this);
            View v = inflater.inflate(R.layout.categories, parent, false);

            return new categoriesActivity.ActivityHolder(v);
        }

        @Override
        public void onBindViewHolder(categoriesActivity.ActivityHolder holder, int position) {

                category_product product1 = products.get(position);

                holder.bindProduct(product1);


        }

        @Override
        public int getItemCount() {
            return products.size();
        }
    }


    /************************************************************/
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mRecyclerrView.setVisibility(show ? View.GONE : View.VISIBLE);
            mRecyclerrView.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mRecyclerrView.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mRecyclerrView.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }

    /*************************************************************/





}
