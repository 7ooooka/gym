package my.gym;

import java.io.Serializable;

public class product {

    private String productId;
    private String product_title;
    private String product_description;
    private String product_price;
    private String product_shipping;
    private String product_link;
    private String product_stock;
    private String product_save;
    private String product_image;
    private String product_category;
    private String categories_products_id;
    private String categories_products_title;
    private String categories_products_image;

    public String getCategories_products_id() {
        return categories_products_id;
    }

    public void setCategories_products_id(String categories_products_id) {
        this.categories_products_id = categories_products_id;
    }

    public String getCategories_products_title() {
        return categories_products_title;
    }

    public void setCategories_products_title(String categories_products_title) {
        this.categories_products_title = categories_products_title;
    }

    public String getCategories_products_image() {
        return categories_products_image;
    }

    public void setCategories_products_image(String categories_products_image) {
        this.categories_products_image = categories_products_image;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProduct_title() {
        return product_title;
    }

    public void setProduct_title(String product_title) {
        this.product_title = product_title;
    }

    public String getProduct_description() {
        return product_description;
    }

    public void setProduct_description(String product_description) {
        this.product_description = product_description;
    }

    public String getProduct_price() {
        return product_price;
    }

    public void setProduct_price(String product_price) {
        this.product_price = product_price;
    }

    public String getProduct_shipping() {
        return product_shipping;
    }

    public void setProduct_shipping(String product_shipping) {
        this.product_shipping = product_shipping;
    }

    public String getProduct_link() {
        return product_link;
    }

    public void setProduct_link(String product_link) {
        this.product_link = product_link;
    }

    public String getProduct_stock() {
        return product_stock;
    }

    public void setProduct_stock(String product_stock) {
        this.product_stock = product_stock;
    }

    public String getProduct_save() {
        return product_save;
    }

    public void setProduct_save(String product_save) {
        this.product_save = product_save;
    }

    public String getProduct_image() {
        return product_image;
    }

    public void setProduct_image(String product_image) {
        this.product_image = product_image;
    }

    public String getProduct_category() {
        return product_category;
    }

    public void setProduct_category(String product_category) {
        this.product_category = product_category;
    }
}
