package my.gym;

public class workoutClass {
    private String workout_id;
    private String workout_title;
    private String workout_description;
    private String workout_cover;
    private String workout_duration;
    private String workout_diffculty;
    private String workout_goals;

    public String getWorkout_id() {
        return workout_id;
    }

    public void setWorkout_id(String workout_id) {
        this.workout_id = workout_id;
    }

    public String getWorkout_title() {
        return workout_title;
    }

    public void setWorkout_title(String workout_title) {
        this.workout_title = workout_title;
    }

    public String getWorkout_description() {
        return workout_description;
    }

    public void setWorkout_description(String workout_description) {
        this.workout_description = workout_description;
    }

    public String getWorkout_cover() {
        return workout_cover;
    }

    public void setWorkout_cover(String workout_cover) {
        this.workout_cover = workout_cover;
    }

    public String getWorkout_duration() {
        return workout_duration;
    }

    public void setWorkout_duration(String workout_duration) {
        this.workout_duration = workout_duration;
    }

    public String getWorkout_diffculty() {
        return workout_diffculty;
    }

    public void setWorkout_diffculty(String workout_diffculty) {
        this.workout_diffculty = workout_diffculty;
    }

    public String getWorkout_goals() {
        return workout_goals;
    }

    public void setWorkout_goals(String workout_goals) {
        this.workout_goals = workout_goals;
    }
}