package my.gym;

public class bodyParts {

    private String bodypart_id;
    private String bodypart_name;
    private String bodypart_thumbnail;

    public String getBodypart_id() {
        return bodypart_id;
    }

    public void setBodypart_id(String bodypart_id) {
        this.bodypart_id = bodypart_id;
    }

    public String getBodypart_name() {
        return bodypart_name;
    }

    public void setBodypart_name(String bodypart_name) {
        this.bodypart_name = bodypart_name;
    }

    public String getBodypart_thumbnail() {
        return bodypart_thumbnail;
    }

    public void setBodypart_thumbnail(String bodypart_thumbnail) {
        this.bodypart_thumbnail = bodypart_thumbnail;
    }
}
