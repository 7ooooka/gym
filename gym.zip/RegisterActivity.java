package my.gym;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import my.gym.R;

import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {

    private EditText name;
    public EditText age;
    private EditText mail;
    private EditText gender;

    public EditText goal;
    public Button signUp;

private RequestQueue mRequestQueue;
private static final String URL = "http://fitnessgymapp.000webhostapp.com/ionic/ionic/backend/controller/new_subscribers.php";
private StringRequest request;


    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    public void showNotification()
    {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this);
        builder.setSmallIcon(R.drawable.shop);
        builder.setContentTitle("Gym app");
        builder.setContentText("Welcome in Gym app for Fitness");
        Intent i = new Intent(RegisterActivity.this,mainPage.class);
        TaskStackBuilder stackBuilder = TaskStackBuilder.create(this);
        stackBuilder.addParentStack(mainPage.class);
        stackBuilder.addNextIntent(i);
        PendingIntent pendingIntent = stackBuilder.getPendingIntent
                (0,PendingIntent.FLAG_UPDATE_CURRENT);
        builder.setContentIntent(pendingIntent);
        NotificationManager nm  = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(0,builder.build());

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        name = findViewById(R.id.namee);
        age  = findViewById(R.id.age);
        mail = findViewById(R.id.mail);
        gender = findViewById(R.id.gender);
        goal = findViewById(R.id.productTitle);

        signUp = findViewById(R.id.register);
        mRequestQueue = Volley.newRequestQueue(this);
        signUp.setOnClickListener(new View.OnClickListener() {

      @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
      @Override
      public void onClick(View view) {
          if (!name.getText().toString().matches("") && !age.getText().toString().matches("")
                  && !mail.getText().toString().matches("") && !gender.getText().toString().matches("")
                  && !goal.getText().toString().matches("")
          )
          {
              showNotification();
          request = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
              @Override
              public void onResponse(String response) {

              }
          }, new Response.ErrorListener() {
              @Override
              public void onErrorResponse(VolleyError error) {

              }
          }


          ) {
              @Override
              protected Map<String, String> getParams() throws AuthFailureError {
                  HashMap<String, String> hashmap = new HashMap<String, String>();
                  hashmap.put("name", name.getText().toString());
                  hashmap.put("age", age.getText().toString());
                  hashmap.put("mail", mail.getText().toString());
                  hashmap.put("gender", gender.getText().toString());
                  hashmap.put("goal", goal.getText().toString());
                  return hashmap;
              }
          };
          mRequestQueue.add(request);
          Toast.makeText(getApplicationContext(), "rigstered", Toast.LENGTH_LONG).show();
          Intent i = new Intent(RegisterActivity.this, mainPage.class);
          startActivity(i);
      }
          else {
              Toast.makeText(getApplicationContext(), "please fill all fields", Toast.LENGTH_LONG).show();
          }
      }
  });


    }


}
